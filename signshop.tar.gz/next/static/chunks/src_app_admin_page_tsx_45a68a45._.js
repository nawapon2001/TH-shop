(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_7a8ab418._.js",
  "static/chunks/node_modules_ed2d2cf6._.js"
],
    source: "dynamic"
});
