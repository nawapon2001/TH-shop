(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_7e94208a._.js",
  "static/chunks/node_modules_dfd40070._.js"
],
    source: "dynamic"
});
