module.exports = {

"[project]/src/models/User.ts [app-route] (ecmascript, async loader)": ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/src_models_User_ts_031f7e97._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/models/User.ts [app-route] (ecmascript)");
    });
});
}),

};