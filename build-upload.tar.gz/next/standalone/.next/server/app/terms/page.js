(()=>{var a={};a.id=7066,a.ids=[7066],a.modules={261:a=>{"use strict";a.exports=require("next/dist/shared/lib/router/utils/app-paths")},3295:a=>{"use strict";a.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},4038:(a,b,c)=>{Promise.resolve().then(c.t.bind(c,16133,23)),Promise.resolve().then(c.t.bind(c,16444,23)),Promise.resolve().then(c.t.bind(c,16042,23)),Promise.resolve().then(c.t.bind(c,49477,23)),Promise.resolve().then(c.t.bind(c,29345,23)),Promise.resolve().then(c.t.bind(c,12089,23)),Promise.resolve().then(c.t.bind(c,46577,23)),Promise.resolve().then(c.t.bind(c,31307,23)),Promise.resolve().then(c.t.bind(c,14817,23))},6492:(a,b,c)=>{"use strict";c.r(b),c.d(b,{default:()=>d});let d=(0,c(61369).registerClientReference)(function(){throw Error("Attempted to call the default export of \"D:\\\\ShopLL\\\\signshop-fullstack\\\\src\\\\app\\\\terms\\\\page.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"D:\\ShopLL\\signshop-fullstack\\src\\app\\terms\\page.tsx","default")},10846:a=>{"use strict";a.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},19121:a=>{"use strict";a.exports=require("next/dist/server/app-render/action-async-storage.external.js")},22190:(a,b,c)=>{Promise.resolve().then(c.t.bind(c,25227,23)),Promise.resolve().then(c.t.bind(c,86346,23)),Promise.resolve().then(c.t.bind(c,27924,23)),Promise.resolve().then(c.t.bind(c,40099,23)),Promise.resolve().then(c.t.bind(c,38243,23)),Promise.resolve().then(c.t.bind(c,28827,23)),Promise.resolve().then(c.t.bind(c,62763,23)),Promise.resolve().then(c.t.bind(c,97173,23)),Promise.resolve().then(c.bind(c,25587))},26713:a=>{"use strict";a.exports=require("next/dist/shared/lib/router/utils/is-bot")},28354:a=>{"use strict";a.exports=require("util")},29294:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-async-storage.external.js")},32414:()=>{},33873:a=>{"use strict";a.exports=require("path")},41025:a=>{"use strict";a.exports=require("next/dist/server/app-render/dynamic-access-async-storage.external.js")},56322:(a,b,c)=>{"use strict";c.r(b),c.d(b,{default:()=>e});var d=c(60687);function e(){let a=`
# ข้อตกลงการใช้งานแพลตฟอร์ม **TH-THAI** (Terms of Service)

อัปเดตล่าสุด: [[ใส่วันที่มีผลบังคับใช้]]

> เอกสารฉบับนี้เป็นเทมเพลตเพื่อการใช้งานทั่วไป มิใช่คำแนะนำทางกฎหมาย โปรดให้ทนายความตรวจทานก่อนประกาศใช้จริง

---

## 1) การยอมรับข้อตกลง

เมื่อเข้าถึงหรือใช้งานแพลตฟอร์ม TH-THAI (“แพลตฟอร์ม”) รวมถึงเว็บไซต์ แอปพลิเคชันหรือบริการที่เกี่ยวข้อง ท่านยอมรับและผูกพันตามข้อตกลงฉบับนี้และนโยบายที่อ้างถึงทั้งหมด (เช่น นโยบายความเป็นส่วนตัว/คุกกี้/นโยบายการคืนสินค้า) หากท่านไม่เห็นด้วย โปรดหยุดการใช้งานทันที

## 2) ผู้ให้บริการและการติดต่อ

**ผู้ให้บริการ:** [[ใส่นิติบุคคลที่รับผิดชอบ]] (“เรา/ผู้ให้บริการ”)
**ที่อยู่ติดต่อ:** [[ที่อยู่สำนักงาน]]
**อีเมล:** [[อีเมลซัพพอร์ต]]
**โทรศัพท์:** [[เบอร์โทร]]

## 3) คำจำกัดความ

* **ผู้ใช้**: บุคคลธรรมดาหรือนิติบุคคลที่เข้าถึงแพลตฟอร์ม (รวมถึงผู้ซื้อและผู้ขาย)
* **ผู้ซื้อ**: ผู้ใช้ที่สั่งซื้อหรือชำระค่าสินค้า/บริการ
* **ผู้ขาย/ร้านค้า**: ผู้ใช้ที่ลงทะเบียนเพื่อเสนอขายสินค้า/บริการ (ใช้เมื่อแพลตฟอร์มทำงานแบบมาร์เก็ตเพลส)
* **คำสั่งซื้อ**: ธุรกรรมการซื้อสินค้าผ่านแพลตฟอร์ม
* **เนื้อหาผู้ใช้ (User Content)**: ข้อความ รูปภาพ รีวิว หรือข้อมูลอื่นใดที่ผู้ใช้ส่ง/อัปโหลด

## 4) คุณสมบัติผู้ใช้และบัญชี

* ผู้ใช้ต้องมีอายุอย่างน้อย 18 ปี หรือได้รับความยินยอมจากผู้ปกครองตามกฎหมาย
* ต้องให้ข้อมูลที่ถูกต้องและอัปเดตเสมอ และรับผิดชอบต่อความปลอดภัยของบัญชี/รหัสผ่าน
* เราสงวนสิทธิ์ในการระงับหรือยกเลิกบัญชีหากพบการละเมิดข้อตกลงหรือกิจกรรมต้องสงสัย

## 5) การทำคำสั่งซื้อและการทำสัญญา

* การแสดงสินค้าเป็นเพียง “คำเชิญให้เสนอซื้อ” (invitation to treat) คำสั่งซื้อของท่านคือข้อเสนอ เมื่อเรา “ยืนยันคำสั่งซื้อ” ถือว่ามีสัญญาซื้อขายเกิดขึ้น
* เราอาจปฏิเสธ/ยกเลิกคำสั่งซื้อได้ในกรณี: สินค้าหมด/ข้อมูลราคาไม่ถูกต้อง/สงสัยทุจริต/ไม่ผ่านการยืนยันตัวตน

## 6) ราคา โปรโมชั่น และความผิดพลาด (Errors)

* ราคาจะแสดงเป็นสกุลบาทไทย (THB) เว้นแต่ระบุไว้เป็นอย่างอื่น และอาจเปลี่ยนแปลงได้โดยไม่ต้องแจ้งล่วงหน้า
* ในกรณีแสดงราคาหรือข้อมูลผิดพลาดอย่างชัดแจ้ง เราสงวนสิทธิ์ในการยกเลิกคำสั่งซื้อและคืนเงินเต็มจำนวน
* คูปอง/โปรโมชันมีเงื่อนไขเฉพาะ กำหนดเวลา และโควตา โปรดอ่านก่อนใช้งาน

## 7) การชำระเงิน

รองรับวิธีการต่อไปนี้: โอนเงิน (Bank Transfer), บัตร (Card), เก็บเงินปลายทาง (COD) และวิธีอื่นที่ประกาศบนแพลตฟอร์ม

* การชำระเงินอาจผ่านผู้ให้บริการรับชำระ (Payment Gateway) ของบุคคลที่สาม
* สำหรับ COD ผู้ซื้อยินยอมรับผิดชอบค่าใช้จ่ายเพิ่มเติม (เช่น COD Fee) หากระบุ
* การปฏิเสธรับสินค้าซ้ำซากอาจนำไปสู่การระงับสิทธิการใช้ COD หรือบัญชี
* ท่านรับผิดชอบค่าธรรมเนียมธนาคาร/อัตราแลกเปลี่ยน (หากมี)

## 8) การจัดส่ง ความเสี่ยง และการโอนกรรมสิทธิ์

* วิธีจัดส่ง: มาตรฐาน/ด่วนพิเศษ หรือรูปแบบอื่นตามที่แสดงในขั้นตอนชำระเงิน
* ระยะเวลาจัดส่งเป็นการประมาณการ อาจล่าช้าเนื่องจากปัจจัยนอกเหนือการควบคุม
* ความเสี่ยงในความเสียหายหรือสูญหายโอนสู่ผู้ซื้อเมื่อบริษัทขนส่งรับสินค้า เว้นแต่กฎหมายบังคับกำหนดเป็นอย่างอื่น
* โปรดตรวจสอบพัสดุเมื่อได้รับ และแจ้งปัญหาภายใน [[ใส่จำนวน]] วันทำการ

## 9) การยกเลิก คืนเงิน และการคืนสินค้า

* นโยบายคืนสินค้า: ภายใน [[เช่น 7]] วันนับจากวันที่ได้รับสินค้า (สินค้าและแพ็กเกจต้องอยู่ในสภาพใหม่/พร้อมหลักฐานการสั่งซื้อ)
* ไม่รับคืน: สินค้าส่วนบุคคล/สั่งทำ, ซอฟต์แวร์/สินค้าดิจิทัลที่เปิดใช้งานแล้ว, สินค้าใกล้หมดอายุ, ชุดชั้นใน/สุขอนามัย ฯลฯ เว้นแต่มีข้อบกพร่อง
* ขั้นตอนการคืน: ติดต่อซัพพอร์ต → รับเลขที่เคส → ส่งคืนตามคำแนะนำ → ตรวจสอบ/อนุมัติ → คืนเงินตามวิธีชำระเงินเดิมภายใน [[เช่น 7–14]] วันทำการ (ไม่รวมค่าขนส่ง/ค่าบริการยกเว้นกรณีสินค้ามีปัญหา)

## 10) สินค้าดิจิทัล/คีย์/โค้ด (ถ้ามี)

* การจัดส่งอาจเป็นลิงก์/โค้ด/คีย์ผ่านอีเมล/บัญชีผู้ใช้
* อาจมีลิมิตการใช้งาน/การเปิดใช้งาน/การถ่ายโอน ตามที่ระบุโดยผู้ผลิต/ซัพพลายเออร์

## 11) เนื้อหาผู้ใช้และรีวิว

* ผู้ใช้รับรองว่าเนื้อหาที่ส่งขึ้นไม่ละเมิดกฎหมาย/ทรัพย์สินทางปัญญา/ความเป็นส่วนตัว/สิทธิของบุคคลอื่น และไม่มีเนื้อหาผิดกฎหมาย ลามก อนาจาร ความรุนแรง ความเกลียดชัง หรือทำให้เข้าใจผิด
* โดยการส่งเนื้อหา ผู้ใช้ให้สิทธิ์เราแบบไม่ผูกขาด โอนไปยังผู้อื่นได้ ไม่มีค่าตอบแทน และใช้ได้ทั่วโลก (license) เพื่อใช้ ทำซ้ำ ปรับปรุง เผยแพร่ แสดง และสร้างสรรค์งานต่อเนื่องเพื่อการดำเนินงานของแพลตฟอร์ม
* เราสงวนสิทธิ์ลบ/ซ่อน/ปรับแก้เนื้อหาที่ฝ่าฝืน

## 12) การใช้งานที่ต้องห้าม

ห้ามกระทำการดังต่อไปนี้ (ตัวอย่าง):

* ละเมิดกฎหมาย/ระเบียบที่เกี่ยวข้อง, ฟอกเงิน, ฉ้อโกง
* โพสต์/ขายสินค้าต้องห้าม: อาวุธ ปลอมแปลง ยาเสพติด สารอันตราย สินค้าละเมิดลิขสิทธิ์/เครื่องหมายการค้า เนื้อหาลามกอนาจารเด็ก ฯลฯ
* เก็บหรือประมวลผลข้อมูลส่วนบุคคลของผู้อื่นโดยไม่ได้รับอนุญาต
* สแครปข้อมูล ออโตบอต แฮ็ก เจาะระบบ สร้างภาระระบบโดยมิชอบ หรือทำสิ่งใดเพื่อหลบเลี่ยงมาตรการด้านความปลอดภัย

## 13) นโยบายมาร์เก็ตเพลส (ถ้าใช้)

* สำหรับคำสั่งซื้อที่ดำเนินการโดยผู้ขายบุคคลที่สาม สัญญาซื้อขายเกิดขึ้นระหว่าง “ผู้ซื้อ” และ “ผู้ขาย” โดย TH-THAI ทำหน้าที่เป็นผู้ให้บริการแพลตฟอร์ม/ตัวกลางเท่านั้น
* ผู้ขายต้องปฏิบัติตามกฎหมายผู้บริโภค ภาษี การออกใบกำกับภาษี/ใบเสร็จ และการรับประกันสินค้า
* กรณีข้อพิพาท เราอาจอำนวยความสะดวกการไกล่เกลี่ยตามขั้นตอนข้อพิพาท (ข้อ 18) แต่ไม่ใช่คู่สัญญารับผิดหลัก เว้นแต่ขายในนาม TH-THAI โดยตรง

## 14) ทรัพย์สินทางปัญญาและสิทธิการใช้งาน

* เนื้อหา เครื่องหมายการค้า โลโก้ ซอฟต์แวร์ และองค์ประกอบทั้งหมดบนแพลตฟอร์มเป็นทรัพย์สินของเรา/ผู้อนุญาตให้ใช้สิทธิ
* ให้สิทธิ์ผู้ใช้แบบจำกัด เพิกถอนได้ และไม่สามารถโอนสิทธิ์ เพื่อเข้าถึงและใช้แพลตฟอร์มตามปกติสำหรับการซื้อขายตามข้อตกลงนี้เท่านั้น

## 15) ความเป็นส่วนตัวและคุกกี้

* การประมวลผลข้อมูลส่วนบุคคลเป็นไปตาม **นโยบายความเป็นส่วนตัว** ของ TH-THAI (สอดคล้องกับกฎหมายคุ้มครองข้อมูลส่วนบุคคลที่ใช้บังคับ)
* เราใช้คุกกี้/เทคโนโลยีที่คล้ายกันเพื่อวัตถุประสงค์ด้านฟังก์ชัน การวิเคราะห์ และการปรับแต่งประสบการณ์ผู้ใช้

## 16) การรับประกันและข้อจำกัดความรับผิด

* แพลตฟอร์มให้บริการ “ตามสภาพ” และ “ตามที่มีอยู่” โดยไม่รับประกันใด ๆ ทั้งชัดแจ้งหรือโดยนัย เว้นแต่บังคับโดยกฎหมาย
* ในขอบเขตสูงสุดตามที่กฎหมายอนุญาต เราไม่รับผิดต่อความเสียหายทางอ้อม พิเศษ โดยบังเอิญ สูญเสียกำไร/ข้อมูล หรือค่าเสียหายเชิงลงโทษที่เกิดจากการใช้งานแพลตฟอร์ม

## 17) การชดใช้ค่าเสียหาย (Indemnity)

ผู้ใช้ตกลงชดใช้ ป้องกัน และไม่ให้เราได้รับความเสียหายจากการเรียกร้องหรือค่าใช้จ่ายใด ๆ ที่เกิดจากการละเมิดข้อตกลงนี้ การใช้แพลตฟอร์มโดยมิชอบ หรือการละเมิดสิทธิของบุคคลที่สามของผู้ใช้

## 18) ข้อพิพาท กฎหมายที่ใช้บังคับ และเขตอำนาจศาล

* ข้อตกลงนี้อยู่ภายใต้กฎหมายไทย
* หากเกิดข้อพิพาท คู่สัญญาจะพยายามเจรจาไกล่เกลี่ยกันภายใน [[เช่น 30]] วันก่อนดำเนินคดี
* หากยุติไม่ได้ ให้อยู่ภายใต้เขตอำนาจศาลของศาลไทยที่มีอำนาจ เว้นแต่จะตกลงใช้อนุญาโตตุลาการเป็นกรณีพิเศษ

## 19) การระงับ/ยกเลิกและผลของการยกเลิก

* เราอาจระงับ/ยกเลิกการเข้าถึงหากพบการละเมิดหรือมีเหตุผลอันควรเชื่อว่ากิจกรรมอาจสร้างความเสียหาย
* ข้อกำหนดที่โดยสภาพต้องคงอยู่ (เช่น ทรัพย์สินทางปัญญา การจำกัดความรับผิด การชดใช้หนี้ ข้อพิพาท) จะยังคงมีผลหลังการยกเลิก

## 20) การเปลี่ยนแปลงข้อตกลง

* เราอาจปรับปรุงแก้ไขข้อตกลงได้เป็นครั้งคราว โดยจะแจ้งให้ทราบผ่านหน้าเว็บไซต์/อีเมล โดยระบุวันที่มีผล
* การใช้งานต่อเนื่องหลังจากวันที่มีผล ถือว่าท่านยอมรับการเปลี่ยนแปลง

## 21) เงื่อนไขเฉพาะบริการ

บริการหรือแคมเปญบางประเภทอาจมีเงื่อนไขเฉพาะเพิ่มเติม ซึ่งจะถือเป็นส่วนหนึ่งของข้อตกลงนี้เมื่อท่านเข้าร่วม

## 22) ข้อกำหนดทั่วไป

* หากข้อกำหนดใดเป็นโมฆะ ข้อกำหนดอื่น ๆ ยังคงมีผล
* การไม่ใช้สิทธิของฝ่ายหนึ่งไม่ถือเป็นการสละสิทธิ์
* ห้ามโอนสิทธิหรือหน้าที่ตามข้อตกลงนี้โดยไม่ได้รับความยินยอมเป็นลายลักษณ์อักษร

---

## ภาคผนวก A — เงื่อนไขสำหรับผู้ขาย (เฉพาะมาร์เก็ตเพลส)

1. **การสมัครและยืนยันตัวตน**: ต้องส่งเอกสารยืนยันตัวตน/นิติบุคคลและบัญชีรับเงินตามที่แพลตฟอร์มกำหนด
2. **การลงประกาศสินค้า**: ต้องแสดงข้อมูลที่ถูกต้อง ราคา ภาษี ค่าจัดส่ง สต็อก และข้อจำกัดการใช้งานอย่างชัดเจน
3. **สินค้าต้องห้าม/จำกัด**: อาวุธ ปลอมแปลง ยาเสพติด สารอันตราย สื่อลามกผิดกฎหมาย ยาสูบ แอลกอฮอล์ ยา/เวชภัณฑ์ที่ต้องมีใบอนุญาต ฯลฯ
4. **การจัดส่งและ SLA**: จัดส่งภายใน [[เช่น 2–3]] วันทำการ หลังได้รับชำระเงิน/ยืนยันคำสั่งซื้อ พร้อมให้เลขติดตาม
5. **การคืน/เคลม**: ผู้ขายต้องปฏิบัติตามนโยบายคืนสินค้าของแพลตฟอร์มและกฎหมายผู้บริโภค
6. **ค่าธรรมเนียมและการจ่ายเงิน**: แพลตฟอร์มอาจเรียกเก็บค่าธรรมเนียม [[เช่น x% ต่อคำสั่งซื้อ]] และจ่ายเงินรอบ [[เช่น รายสัปดาห์]] หักคืน/เคลม/ชาร์จแบ็กตามจริง
7. **ภาษี**: ผู้ขายรับผิดชอบภาษีทั้งหมดที่เกี่ยวข้อง รวมถึงการออกเอกสารภาษี
8. **การปฏิบัติตามกฎหมาย**: ต้องปฏิบัติตามกฎหมายโฆษณา ความปลอดภัยสินค้า มาตรฐาน อนุญาตพิเศษ และทรัพย์สินทางปัญญา
9. **โทษฝ่าฝืน**: ระงับบัญชี ลบสินค้า ปรับ/หักเงิน และยกเลิกสิทธิการขายบนแพลตฟอร์ม

---

## ช่องทางติดต่อ TH-THAI

* อีเมลซัพพอร์ต: [[อีเมล]]
* แบบฟอร์มติดต่อ: [[ลิงก์ฟอร์ม]]
* เวลาทำการ: [[เช่น จันทร์–ศุกร์ 09:00–18:00 น.]]

> โดยการคลิก “ยอมรับ” หรือใช้งานแพลตฟอร์มอย่างต่อเนื่อง ท่านยืนยันว่าได้อ่าน เข้าใจ และยอมรับข้อกำหนดทั้งหมดข้างต้นแล้ว
`;return(0,d.jsx)("div",{className:"min-h-screen bg-gradient-to-br from-orange-50 to-amber-50 py-10",children:(0,d.jsxs)("div",{className:"max-w-3xl mx-auto bg-white rounded-2xl border border-orange-200 shadow-xl p-8",children:[(0,d.jsx)("h1",{className:"text-3xl font-bold text-orange-700 mb-6",children:"ข้อตกลงการใช้งานแพลตฟอร์ม TH-THAI"}),(0,d.jsx)("pre",{className:"whitespace-pre-wrap text-base text-slate-800",children:a})]})})}c(43210)},61135:()=>{},63033:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},70440:(a,b,c)=>{"use strict";c.r(b),c.d(b,{default:()=>e});var d=c(31658);let e=async a=>[{type:"image/x-icon",sizes:"16x16",url:(0,d.fillMetadataSegment)(".",await a.params,"favicon.ico")+""}]},85606:(a,b,c)=>{Promise.resolve().then(c.bind(c,56322))},86439:a=>{"use strict";a.exports=require("next/dist/shared/lib/no-fallback-error.external")},93854:(a,b,c)=>{Promise.resolve().then(c.bind(c,6492))},94431:(a,b,c)=>{"use strict";c.r(b),c.d(b,{default:()=>j,metadata:()=>i});var d=c(37413),e=c(22376),f=c.n(e),g=c(68726),h=c.n(g);c(61135);let i={title:"Create Next App",description:"Generated by create next app"};function j({children:a}){return(0,d.jsx)("html",{lang:"en",children:(0,d.jsx)("body",{className:`${f().variable} ${h().variable} antialiased`,children:a})})}},97881:(a,b,c)=>{"use strict";c.r(b),c.d(b,{GlobalError:()=>C.a,__next_app__:()=>I,handler:()=>K,pages:()=>H,routeModule:()=>J,tree:()=>G});var d=c(65239),e=c(48088),f=c(47220),g=c(81289),h=c(26191),i=c(14823),j=c(71998),k=c(92603),l=c(54649),m=c(32781),n=c(82602),o=c(61268),p=c(4853),q=c(261),r=c(5052),s=c(9977),t=c(26713),u=c(43365),v=c(71454),w=c(67778),x=c(46143),y=c(39105),z=c(38171),A=c(86439),B=c(16133),C=c.n(B),D=c(30893),E=c(52836),F={};for(let a in D)0>["default","tree","pages","GlobalError","__next_app__","routeModule","handler"].indexOf(a)&&(F[a]=()=>D[a]);c.d(b,F);let G={children:["",{children:["terms",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(c.bind(c,6492)),"D:\\ShopLL\\signshop-fullstack\\src\\app\\terms\\page.tsx"]}]},{metadata:{icon:[async a=>(await Promise.resolve().then(c.bind(c,70440))).default(a)],apple:[],openGraph:[],twitter:[],manifest:void 0}}]},{layout:[()=>Promise.resolve().then(c.bind(c,94431)),"D:\\ShopLL\\signshop-fullstack\\src\\app\\layout.tsx"],"global-error":[()=>Promise.resolve().then(c.t.bind(c,16133,23)),"next/dist/client/components/builtin/global-error.js"],"not-found":[()=>Promise.resolve().then(c.t.bind(c,80849,23)),"next/dist/client/components/builtin/not-found.js"],forbidden:[()=>Promise.resolve().then(c.t.bind(c,29868,23)),"next/dist/client/components/builtin/forbidden.js"],unauthorized:[()=>Promise.resolve().then(c.t.bind(c,79615,23)),"next/dist/client/components/builtin/unauthorized.js"],metadata:{icon:[async a=>(await Promise.resolve().then(c.bind(c,70440))).default(a)],apple:[],openGraph:[],twitter:[],manifest:void 0}}]}.children,H=["D:\\ShopLL\\signshop-fullstack\\src\\app\\terms\\page.tsx"],I={require:c,loadChunk:()=>Promise.resolve()},J=new d.AppPageRouteModule({definition:{kind:e.RouteKind.APP_PAGE,page:"/terms/page",pathname:"/terms",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:G},distDir:".next",projectDir:""});async function K(a,b,c){var d;let B="/terms/page";"/index"===B&&(B="/");let F="false",L=(0,h.getRequestMeta)(a,"postponed"),M=(0,h.getRequestMeta)(a,"minimalMode"),N=await J.prepare(a,b,{srcPage:B,multiZoneDraftMode:F});if(!N)return b.statusCode=400,b.end("Bad Request"),null==c.waitUntil||c.waitUntil.call(c,Promise.resolve()),null;let{buildId:O,query:P,params:Q,parsedUrl:R,pageIsDynamic:S,buildManifest:T,nextFontManifest:U,reactLoadableManifest:V,serverActionsManifest:W,clientReferenceManifest:X,subresourceIntegrityManifest:Y,prerenderManifest:Z,isDraftMode:$,resolvedPathname:_,revalidateOnlyGenerated:aa,routerServerContext:ab,nextConfig:ac}=N,ad=R.pathname||"/",ae=(0,q.normalizeAppPath)(B),{isOnDemandRevalidate:af}=N,ag=Z.dynamicRoutes[ae],ah=Z.routes[_],ai=!!(ag||ah||Z.routes[ae]),aj=a.headers["user-agent"]||"",ak=(0,t.getBotType)(aj),al=(0,o.isHtmlBotRequest)(a),am=(0,h.getRequestMeta)(a,"isPrefetchRSCRequest")??!!a.headers[s.NEXT_ROUTER_PREFETCH_HEADER],an=(0,h.getRequestMeta)(a,"isRSCRequest")??!!a.headers[s.RSC_HEADER],ao=(0,r.getIsPossibleServerAction)(a),ap=(0,l.checkIsAppPPREnabled)(ac.experimental.ppr)&&(null==(d=Z.routes[ae]??Z.dynamicRoutes[ae])?void 0:d.renderingMode)==="PARTIALLY_STATIC",aq=!1,ar=!1,as=ap?L:void 0,at=ap&&an&&!am,au=(0,h.getRequestMeta)(a,"segmentPrefetchRSCRequest"),av=!aj||(0,o.shouldServeStreamingMetadata)(aj,ac.htmlLimitedBots);al&&ap&&(ai=!1,av=!1);let aw=!0===J.isDev||!ai||"string"==typeof L||at,ax=al&&ap,ay=null;$||!ai||aw||ao||as||at||(ay=_);let az=ay;!az&&J.isDev&&(az=_);let aA={...D,tree:G,pages:H,GlobalError:C(),handler:K,routeModule:J,__next_app__:I};W&&X&&(0,n.setReferenceManifestsSingleton)({page:B,clientReferenceManifest:X,serverActionsManifest:W,serverModuleMap:(0,p.createServerModuleMap)({serverActionsManifest:W})});let aB=a.method||"GET",aC=(0,g.getTracer)(),aD=aC.getActiveScopeSpan();try{let d=async(c,d)=>{let e=new k.NodeNextRequest(a),f=new k.NodeNextResponse(b);return J.render(e,f,d).finally(()=>{if(!c)return;c.setAttributes({"http.status_code":b.statusCode,"next.rsc":!1});let d=aC.getRootSpanAttributes();if(!d)return;if(d.get("next.span_type")!==i.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${d.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let e=d.get("next.route");if(e){let a=`${aB} ${e}`;c.setAttributes({"next.route":e,"http.route":e,"next.span_name":a}),c.updateName(a)}else c.updateName(`${aB} ${a.url}`)})},f=async({span:e,postponed:f,fallbackRouteParams:g})=>{let i={query:P,params:Q,page:ae,sharedContext:{buildId:O},serverComponentsHmrCache:(0,h.getRequestMeta)(a,"serverComponentsHmrCache"),fallbackRouteParams:g,renderOpts:{App:()=>null,Document:()=>null,pageConfig:{},ComponentMod:aA,Component:(0,j.T)(aA),params:Q,routeModule:J,page:B,postponed:f,shouldWaitOnAllReady:ax,serveStreamingMetadata:av,supportsDynamicResponse:"string"==typeof f||aw,buildManifest:T,nextFontManifest:U,reactLoadableManifest:V,subresourceIntegrityManifest:Y,serverActionsManifest:W,clientReferenceManifest:X,setIsrStatus:null==ab?void 0:ab.setIsrStatus,dir:J.projectDir,isDraftMode:$,isRevalidate:ai&&!f&&!at,botType:ak,isOnDemandRevalidate:af,isPossibleServerAction:ao,assetPrefix:ac.assetPrefix,nextConfigOutput:ac.output,crossOrigin:ac.crossOrigin,trailingSlash:ac.trailingSlash,previewProps:Z.preview,deploymentId:ac.deploymentId,enableTainting:ac.experimental.taint,htmlLimitedBots:ac.htmlLimitedBots,devtoolSegmentExplorer:ac.experimental.devtoolSegmentExplorer,reactMaxHeadersLength:ac.reactMaxHeadersLength,multiZoneDraftMode:F,incrementalCache:(0,h.getRequestMeta)(a,"incrementalCache"),cacheLifeProfiles:ac.experimental.cacheLife,basePath:ac.basePath,serverActions:ac.experimental.serverActions,...aq?{nextExport:!0,supportsDynamicResponse:!1,isStaticGeneration:!0,isRevalidate:!0,isDebugDynamicAccesses:aq}:{},experimental:{isRoutePPREnabled:ap,expireTime:ac.expireTime,staleTimes:ac.experimental.staleTimes,dynamicIO:!!ac.experimental.dynamicIO,clientSegmentCache:!!ac.experimental.clientSegmentCache,dynamicOnHover:!!ac.experimental.dynamicOnHover,inlineCss:!!ac.experimental.inlineCss,authInterrupts:!!ac.experimental.authInterrupts,clientTraceMetadata:ac.experimental.clientTraceMetadata||[]},waitUntil:c.waitUntil,onClose:a=>{b.on("close",a)},onAfterTaskError:()=>{},onInstrumentationRequestError:(b,c,d)=>J.onRequestError(a,b,d,ab),err:(0,h.getRequestMeta)(a,"invokeError"),dev:J.isDev}},k=await d(e,i),{metadata:l}=k,{cacheControl:m,headers:n={},fetchTags:o}=l;if(o&&(n[x.NEXT_CACHE_TAGS_HEADER]=o),a.fetchMetrics=l.fetchMetrics,ai&&(null==m?void 0:m.revalidate)===0&&!J.isDev&&!ap){let a=l.staticBailoutInfo,b=Object.defineProperty(Error(`Page changed from static to dynamic at runtime ${_}${(null==a?void 0:a.description)?`, reason: ${a.description}`:""}
see more here https://nextjs.org/docs/messages/app-static-to-dynamic-error`),"__NEXT_ERROR_CODE",{value:"E132",enumerable:!1,configurable:!0});if(null==a?void 0:a.stack){let c=a.stack;b.stack=b.message+c.substring(c.indexOf("\n"))}throw b}return{value:{kind:u.CachedRouteKind.APP_PAGE,html:k,headers:n,rscData:l.flightData,postponed:l.postponed,status:l.statusCode,segmentData:l.segmentData},cacheControl:m}},l=async({hasResolved:d,previousCacheEntry:g,isRevalidating:i,span:j})=>{let k,l=!1===J.isDev,n=d||b.writableEnded;if(af&&aa&&!g&&!M)return(null==ab?void 0:ab.render404)?await ab.render404(a,b):(b.statusCode=404,b.end("This page could not be found")),null;if(ag&&(k=(0,v.parseFallbackField)(ag.fallback)),k===v.FallbackMode.PRERENDER&&(0,t.isBot)(aj)&&(k=v.FallbackMode.BLOCKING_STATIC_RENDER),(null==g?void 0:g.isStale)===-1&&(af=!0),af&&(k!==v.FallbackMode.NOT_FOUND||g)&&(k=v.FallbackMode.BLOCKING_STATIC_RENDER),!M&&k!==v.FallbackMode.BLOCKING_STATIC_RENDER&&az&&!n&&!$&&S&&(l||!ah)){let b;if((l||ag)&&k===v.FallbackMode.NOT_FOUND)throw new A.NoFallbackError;if(ap&&!an){if(b=await J.handleResponse({cacheKey:l?ae:null,req:a,nextConfig:ac,routeKind:e.RouteKind.APP_PAGE,isFallback:!0,prerenderManifest:Z,isRoutePPREnabled:ap,responseGenerator:async()=>f({span:j,postponed:void 0,fallbackRouteParams:l||ar?(0,m.u)(ae):null}),waitUntil:c.waitUntil}),null===b)return null;if(b)return delete b.cacheControl,b}}let o=af||i||!as?void 0:as;if(aq&&void 0!==o)return{cacheControl:{revalidate:1,expire:void 0},value:{kind:u.CachedRouteKind.PAGES,html:w.default.fromStatic(""),pageData:{},headers:void 0,status:void 0}};let p=S&&ap&&((0,h.getRequestMeta)(a,"renderFallbackShell")||ar)?(0,m.u)(ad):null;return f({span:j,postponed:o,fallbackRouteParams:p})},n=async d=>{var g,i,j,k,m;let n,o=await J.handleResponse({cacheKey:ay,responseGenerator:a=>l({span:d,...a}),routeKind:e.RouteKind.APP_PAGE,isOnDemandRevalidate:af,isRoutePPREnabled:ap,req:a,nextConfig:ac,prerenderManifest:Z,waitUntil:c.waitUntil});if($&&b.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate"),J.isDev&&b.setHeader("Cache-Control","no-store, must-revalidate"),!o){if(ay)throw Object.defineProperty(Error("invariant: cache entry required but not generated"),"__NEXT_ERROR_CODE",{value:"E62",enumerable:!1,configurable:!0});return null}if((null==(g=o.value)?void 0:g.kind)!==u.CachedRouteKind.APP_PAGE)throw Object.defineProperty(Error(`Invariant app-page handler received invalid cache entry ${null==(j=o.value)?void 0:j.kind}`),"__NEXT_ERROR_CODE",{value:"E707",enumerable:!1,configurable:!0});let p="string"==typeof o.value.postponed;ai&&!at&&(!p||am)&&(M||b.setHeader("x-nextjs-cache",af?"REVALIDATED":o.isMiss?"MISS":o.isStale?"STALE":"HIT"),b.setHeader(s.NEXT_IS_PRERENDER_HEADER,"1"));let{value:q}=o;if(as)n={revalidate:0,expire:void 0};else if(M&&an&&!am&&ap)n={revalidate:0,expire:void 0};else if(!J.isDev)if($)n={revalidate:0,expire:void 0};else if(ai){if(o.cacheControl)if("number"==typeof o.cacheControl.revalidate){if(o.cacheControl.revalidate<1)throw Object.defineProperty(Error(`Invalid revalidate configuration provided: ${o.cacheControl.revalidate} < 1`),"__NEXT_ERROR_CODE",{value:"E22",enumerable:!1,configurable:!0});n={revalidate:o.cacheControl.revalidate,expire:(null==(k=o.cacheControl)?void 0:k.expire)??ac.expireTime}}else n={revalidate:x.CACHE_ONE_YEAR,expire:void 0}}else b.getHeader("Cache-Control")||(n={revalidate:0,expire:void 0});if(o.cacheControl=n,"string"==typeof au&&(null==q?void 0:q.kind)===u.CachedRouteKind.APP_PAGE&&q.segmentData){b.setHeader(s.NEXT_DID_POSTPONE_HEADER,"2");let c=null==(m=q.headers)?void 0:m[x.NEXT_CACHE_TAGS_HEADER];M&&ai&&c&&"string"==typeof c&&b.setHeader(x.NEXT_CACHE_TAGS_HEADER,c);let d=q.segmentData.get(au);return void 0!==d?(0,z.sendRenderResult)({req:a,res:b,type:"rsc",generateEtags:ac.generateEtags,poweredByHeader:ac.poweredByHeader,result:w.default.fromStatic(d),cacheControl:o.cacheControl}):(b.statusCode=204,(0,z.sendRenderResult)({req:a,res:b,type:"rsc",generateEtags:ac.generateEtags,poweredByHeader:ac.poweredByHeader,result:w.default.fromStatic(""),cacheControl:o.cacheControl}))}let r=(0,h.getRequestMeta)(a,"onCacheEntry");if(r&&await r({...o,value:{...o.value,kind:"PAGE"}},{url:(0,h.getRequestMeta)(a,"initURL")}))return null;if(p&&as)throw Object.defineProperty(Error("Invariant: postponed state should not be present on a resume request"),"__NEXT_ERROR_CODE",{value:"E396",enumerable:!1,configurable:!0});if(q.headers){let a={...q.headers};for(let[c,d]of(M&&ai||delete a[x.NEXT_CACHE_TAGS_HEADER],Object.entries(a)))if(void 0!==d)if(Array.isArray(d))for(let a of d)b.appendHeader(c,a);else"number"==typeof d&&(d=d.toString()),b.appendHeader(c,d)}let t=null==(i=q.headers)?void 0:i[x.NEXT_CACHE_TAGS_HEADER];if(M&&ai&&t&&"string"==typeof t&&b.setHeader(x.NEXT_CACHE_TAGS_HEADER,t),!q.status||an&&ap||(b.statusCode=q.status),!M&&q.status&&E.RedirectStatusCode[q.status]&&an&&(b.statusCode=200),p&&b.setHeader(s.NEXT_DID_POSTPONE_HEADER,"1"),an&&!$){if(void 0===q.rscData){if(q.postponed)throw Object.defineProperty(Error("Invariant: Expected postponed to be undefined"),"__NEXT_ERROR_CODE",{value:"E372",enumerable:!1,configurable:!0});return(0,z.sendRenderResult)({req:a,res:b,type:"rsc",generateEtags:ac.generateEtags,poweredByHeader:ac.poweredByHeader,result:q.html,cacheControl:at?{revalidate:0,expire:void 0}:o.cacheControl})}return(0,z.sendRenderResult)({req:a,res:b,type:"rsc",generateEtags:ac.generateEtags,poweredByHeader:ac.poweredByHeader,result:w.default.fromStatic(q.rscData),cacheControl:o.cacheControl})}let v=q.html;if(!p||M)return(0,z.sendRenderResult)({req:a,res:b,type:"html",generateEtags:ac.generateEtags,poweredByHeader:ac.poweredByHeader,result:v,cacheControl:o.cacheControl});if(aq)return v.chain(new ReadableStream({start(a){a.enqueue(y.ENCODED_TAGS.CLOSED.BODY_AND_HTML),a.close()}})),(0,z.sendRenderResult)({req:a,res:b,type:"html",generateEtags:ac.generateEtags,poweredByHeader:ac.poweredByHeader,result:v,cacheControl:{revalidate:0,expire:void 0}});let A=new TransformStream;return v.chain(A.readable),f({span:d,postponed:q.postponed,fallbackRouteParams:null}).then(async a=>{var b,c;if(!a)throw Object.defineProperty(Error("Invariant: expected a result to be returned"),"__NEXT_ERROR_CODE",{value:"E463",enumerable:!1,configurable:!0});if((null==(b=a.value)?void 0:b.kind)!==u.CachedRouteKind.APP_PAGE)throw Object.defineProperty(Error(`Invariant: expected a page response, got ${null==(c=a.value)?void 0:c.kind}`),"__NEXT_ERROR_CODE",{value:"E305",enumerable:!1,configurable:!0});await a.value.html.pipeTo(A.writable)}).catch(a=>{A.writable.abort(a).catch(a=>{console.error("couldn't abort transformer",a)})}),(0,z.sendRenderResult)({req:a,res:b,type:"html",generateEtags:ac.generateEtags,poweredByHeader:ac.poweredByHeader,result:v,cacheControl:{revalidate:0,expire:void 0}})};if(!aD)return await aC.withPropagatedContext(a.headers,()=>aC.trace(i.BaseServerSpan.handleRequest,{spanName:`${aB} ${a.url}`,kind:g.SpanKind.SERVER,attributes:{"http.method":aB,"http.target":a.url}},n));await n(aD)}catch(b){throw aD||b instanceof A.NoFallbackError||await J.onRequestError(a,b,{routerKind:"App Router",routePath:B,routeType:"render",revalidateReason:(0,f.c)({isRevalidate:ai,isOnDemandRevalidate:af})},ab),b}}},98758:()=>{}};var b=require("../../webpack-runtime.js");b.C(a);var c=b.X(0,[4985,2400],()=>b(b.s=97881));module.exports=c})();